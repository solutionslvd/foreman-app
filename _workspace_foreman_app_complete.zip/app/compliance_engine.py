"""
Compliance Engine for Alberta Construction Assistant
Handles WCB, OHS, building permits, and regulatory compliance
"""

from typing import Dict, List, Optional, Any
from datetime import datetime, date, timedelta
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class ComplianceStatus(Enum):
    """Compliance status levels"""
    COMPLIANT = "compliant"
    WARNING = "warning"
    NON_COMPLIANT = "non_compliant"
    ACTION_REQUIRED = "action_required"
    EXPIRED = "expired"


class PermitType(Enum):
    """Types of construction permits"""
    BUILDING = "building"
    ELECTRICAL = "electrical"
    PLUMBING = "plumbing"
    HVAC = "hvac"
    DEMOLITION = "demolition"
    RENOVATION = "renovation"


class InspectionType(Enum):
    """Types of required inspections"""
    FOUNDATION = "foundation"
    FRAMING = "framing"
    INSULATION = "insulation"
    PLUMBING_ROUGH_IN = "plumbing_rough_in"
    ELECTRICAL_ROUGH_IN = "electrical_rough_in"
    FINAL = "final"


class ComplianceEngine:
    """Comprehensive compliance management system for Alberta construction"""
    
    def __init__(self, config=None):
        self.config = config
        self.permits: List[Dict] = []
        self.inspections: List[Dict] = []
        self.safety_records: List[Dict] = []
        self.wcb_records: Dict = {}
        self.training_records: List[Dict] = []
        
    def register_wcb_account(
        self,
        account_number: str,
        business_type: str = "construction_general",
        number_of_workers: int = 1
    ) -> Dict:
        """
        Register WCB account information
        
        Args:
            account_number: WCB account number
            business_type: Type of construction business
            number_of_workers: Number of workers for premium calculation
            
        Returns:
            WCB account record
        """
        # WCB premium rates for different construction types
        premium_rates = {
            "construction_general": 2.50,
            "framing": 3.20,
            "carpentry": 2.80,
            "electrical": 2.10,
            "plumbing": 2.30,
            "roofing": 4.50,
            "concrete": 3.80
        }
        
        premium_rate = premium_rates.get(business_type, 2.50)
        
        wcb_record = {
            "account_number": account_number,
            "business_type": business_type,
            "premium_rate": premium_rate,
            "number_of_workers": number_of_workers,
            "coverage_status": "active",
            "last_premium_payment": None,
            "next_payment_due": self._calculate_next_wcb_payment(),
            "registered_date": datetime.now().date(),
            "annual_assessment": self._calculate_annual_assessment(premium_rate, number_of_workers)
        }
        
        self.wcb_records = wcb_record
        logger.info(f"WCB account registered: {account_number}")
        return wcb_record
    
    def _calculate_next_wcb_payment(self) -> date:
        """Calculate next WCB payment due date"""
        today = datetime.now().date()
        # WCB payments are due quarterly
        if today.month <= 3:
            return date(today.year, 3, 31)
        elif today.month <= 6:
            return date(today.year, 6, 30)
        elif today.month <= 9:
            return date(today.year, 9, 30)
        else:
            return date(today.year, 12, 31)
    
    def _calculate_annual_assessment(
        self,
        premium_rate: float,
        number_of_workers: int
    ) -> float:
        """Calculate annual WCB assessment (simplified)"""
        # Average assessable earnings per worker
        avg_earnings = 55000
        total_assessable_earnings = avg_earnings * number_of_workers
        return total_assessable_earnings * (premium_rate / 100)
    
    def add_permit(
        self,
        permit_type: PermitType,
        permit_number: str,
        project_address: str,
        issue_date: date,
        expiry_date: Optional[date] = None,
        issuing_authority: str = "City of Calgary"
    ) -> Dict:
        """
        Add a construction permit
        
        Args:
            permit_type: Type of permit
            permit_number: Permit number
            project_address: Project address
            issue_date: Date permit was issued
            expiry_date: Permit expiry date (if applicable)
            issuing_authority: Authority that issued the permit
            
        Returns:
            Permit record
        """
        # Default expiry: 1 year from issue date if not specified
        if not expiry_date:
            expiry_date = issue_date + timedelta(days=365)
        
        # Determine required inspections based on permit type
        required_inspections = self._get_required_inspections(permit_type)
        
        permit = {
            "id": len(self.permits) + 1,
            "permit_type": permit_type.value,
            "permit_number": permit_number,
            "project_address": project_address,
            "issue_date": issue_date,
            "expiry_date": expiry_date,
            "issuing_authority": issuing_authority,
            "status": "active",
            "required_inspections": required_inspections,
            "completed_inspections": [],
            "created_at": datetime.now()
        }
        
        self.permits.append(permit)
        logger.info(f"Permit added: {permit_type.value} - {permit_number}")
        return permit
    
    def _get_required_inspections(self, permit_type: PermitType) -> List[str]:
        """Get required inspections for a permit type"""
        inspection_mapping = {
            PermitType.BUILDING: [
                InspectionType.FOUNDATION.value,
                InspectionType.FRAMING.value,
                InspectionType.INSULATION.value,
                InspectionType.FINAL.value
            ],
            PermitType.ELECTRICAL: [
                InspectionType.ELECTRICAL_ROUGH_IN.value,
                InspectionType.FINAL.value
            ],
            PermitType.PLUMBING: [
                InspectionType.PLUMBING_ROUGH_IN.value,
                InspectionType.FINAL.value
            ],
            PermitType.RENOVATION: [
                InspectionType.FRAMING.value,
                InspectionType.FINAL.value
            ]
        }
        return inspection_mapping.get(permit_type, [InspectionType.FINAL.value])
    
    def record_inspection(
        self,
        permit_id: int,
        inspection_type: str,
        inspection_date: date,
        inspector_name: str,
        result: str = "passed",
        findings: Optional[str] = None,
        corrections_required: bool = False
    ) -> Dict:
        """
        Record a construction inspection
        
        Args:
            permit_id: Related permit ID
            inspection_type: Type of inspection
            inspection_date: Date of inspection
            inspector_name: Name of inspector
            result: Inspection result (passed, failed, conditional)
            findings: Inspector's findings
            corrections_required: Whether corrections are required
            
        Returns:
            Inspection record
        """
        inspection = {
            "id": len(self.inspections) + 1,
            "permit_id": permit_id,
            "inspection_type": inspection_type,
            "inspection_date": inspection_date,
            "inspector_name": inspector_name,
            "result": result,
            "findings": findings,
            "corrections_required": corrections_required,
            "correction_deadline": inspection_date + timedelta(days=14) if corrections_required else None,
            "created_at": datetime.now()
        }
        
        self.inspections.append(inspection)
        
        # Update permit's completed inspections
        permit = next((p for p in self.permits if p["id"] == permit_id), None)
        if permit:
            if inspection_type not in permit["completed_inspections"]:
                permit["completed_inspections"].append(inspection_type)
        
        logger.info(f"Inspection recorded: {inspection_type} - {result}")
        return inspection
    
    def record_safety_incident(
        self,
        incident_date: date,
        incident_type: str,
        description: str,
        location: str,
        severity: str = "minor",
        injuries: Optional[List[str]] = None,
        witnesses: Optional[List[str]] = None,
        immediate_actions_taken: Optional[str] = None
    ) -> Dict:
        """
        Record a workplace safety incident
        
        Args:
            incident_date: Date of incident
            incident_type: Type of incident
            description: Detailed description
            location: Location of incident
            severity: Severity level (minor, moderate, severe, critical)
            injuries: List of injuries (if any)
            witnesses: List of witnesses
            immediate_actions_taken: Actions taken immediately after incident
            
        Returns:
            Incident record
        """
        incident = {
            "id": len(self.safety_records) + 1,
            "incident_date": incident_date,
            "incident_type": incident_type,
            "description": description,
            "location": location,
            "severity": severity,
            "injuries": injuries or [],
            "witnesses": witnesses or [],
            "immediate_actions_taken": immediate_actions_taken,
            "reported_to_wcb": False,
            "wcb_report_date": None,
            "investigation_completed": False,
            "corrective_actions": [],
            "status": "open",
            "created_at": datetime.now()
        }
        
        self.safety_records.append(incident)
        
        # Check if WCB reporting is required (within 24 hours for serious incidents)
        if severity in ["severe", "critical"]:
            incident["wcb_reporting_required"] = True
            incident["wcb_deadline"] = incident_date + timedelta(hours=24)
        
        logger.warning(f"Safety incident recorded: {incident_type} - {severity}")
        return incident
    
    def add_training_record(
        self,
        employee_name: str,
        training_type: str,
        training_date: date,
        expiry_date: Optional[date] = None,
        certificate_number: Optional[str] = None,
        training_provider: str = "Internal"
    ) -> Dict:
        """
        Add employee training record
        
        Args:
            employee_name: Employee's name
            training_type: Type of training (WHMIS, First Aid, Fall Protection, etc.)
            training_date: Date training was completed
            expiry_date: Training expiry date (if applicable)
            certificate_number: Certificate number
            training_provider: Provider of training
            
        Returns:
            Training record
        """
        training = {
            "id": len(self.training_records) + 1,
            "employee_name": employee_name,
            "training_type": training_type,
            "training_date": training_date,
            "expiry_date": expiry_date,
            "certificate_number": certificate_number,
            "training_provider": training_provider,
            "status": "valid" if not expiry_date or expiry_date > datetime.now().date() else "expired",
            "created_at": datetime.now()
        }
        
        self.training_records.append(training)
        logger.info(f"Training recorded: {training_type} for {employee_name}")
        return training
    
    def get_compliance_status(self) -> Dict[str, Any]:
        """
        Get overall compliance status
        
        Returns:
            Comprehensive compliance overview
        """
        today = datetime.now().date()
        
        # Check WCB status
        wcb_status = self._check_wcb_status()
        
        # Check permits
        permit_status = self._check_permit_status(today)
        
        # Check inspections
        inspection_status = self._check_inspection_status(today)
        
        # Check training
        training_status = self._check_training_status(today)
        
        # Check safety incidents
        safety_status = self._check_safety_status(today)
        
        # Calculate overall compliance score
        compliance_items = [
            wcb_status["compliant"],
            permit_status["compliant"],
            inspection_status["compliant"],
            training_status["compliant"],
            safety_status["compliant"]
        ]
        
        compliance_score = sum(compliance_items) / len(compliance_items) * 100
        
        # Determine overall status
        if compliance_score >= 90:
            overall_status = ComplianceStatus.COMPLIANT
        elif compliance_score >= 70:
            overall_status = ComplianceStatus.WARNING
        elif compliance_score >= 50:
            overall_status = ComplianceStatus.ACTION_REQUIRED
        else:
            overall_status = ComplianceStatus.NON_COMPLIANT
        
        return {
            "overall_status": overall_status.value,
            "compliance_score": compliance_score,
            "wcb_status": wcb_status,
            "permit_status": permit_status,
            "inspection_status": inspection_status,
            "training_status": training_status,
            "safety_status": safety_status,
            "action_items": self._generate_action_items(
                wcb_status, permit_status, inspection_status, training_status, safety_status
            )
        }
    
    def _check_wcb_status(self) -> Dict[str, Any]:
        """Check WCB compliance status"""
        if not self.wcb_records:
            return {
                "compliant": False,
                "status": "not_registered",
                "message": "WCB account not registered"
            }
        
        today = datetime.now().date()
        next_payment = self.wcb_records.get("next_payment_due")
        
        if next_payment and next_payment < today:
            return {
                "compliant": False,
                "status": "payment_overdue",
                "message": f"WCB payment overdue since {next_payment}"
            }
        
        return {
            "compliant": True,
            "status": "active",
            "message": "WCB coverage is active"
        }
    
    def _check_permit_status(self, today: date) -> Dict[str, Any]:
        """Check permit compliance status"""
        if not self.permits:
            return {
                "compliant": True,
                "status": "no_permits",
                "message": "No permits to check"
            }
        
        expired_permits = [
            p for p in self.permits
            if p["expiry_date"] < today
        ]
        
        expiring_soon = [
            p for p in self.permits
            if 0 <= (p["expiry_date"] - today).days <= 30
        ]
        
        if expired_permits:
            return {
                "compliant": False,
                "status": "expired",
                "message": f"{len(expired_permits)} permit(s) expired",
                "expired_permits": expired_permits
            }
        
        if expiring_soon:
            return {
                "compliant": True,
                "status": "expiring_soon",
                "message": f"{len(expiring_soon)} permit(s) expiring soon",
                "expiring_permits": expiring_soon
            }
        
        return {
            "compliant": True,
            "status": "active",
            "message": "All permits are active"
        }
    
    def _check_inspection_status(self, today: date) -> Dict[str, Any]:
        """Check inspection compliance status"""
        if not self.permits:
            return {
                "compliant": True,
                "status": "no_permits",
                "message": "No permits requiring inspections"
            }
        
        overdue_inspections = []
        for permit in self.permits:
            required = set(permit["required_inspections"])
            completed = set(permit["completed_inspections"])
            missing = required - completed
            
            if missing:
                overdue_inspections.append({
                    "permit": permit["permit_number"],
                    "missing_inspections": list(missing)
                })
        
        if overdue_inspections:
            return {
                "compliant": False,
                "status": "overdue",
                "message": f"{len(overdue_inspections)} permit(s) have overdue inspections",
                "overdue_inspections": overdue_inspections
            }
        
        return {
            "compliant": True,
            "status": "complete",
            "message": "All required inspections completed"
        }
    
    def _check_training_status(self, today: date) -> Dict[str, Any]:
        """Check training compliance status"""
        if not self.training_records:
            return {
                "compliant": True,
                "status": "no_records",
                "message": "No training records to check"
            }
        
        expired_training = [
            t for t in self.training_records
            if t.get("expiry_date") and t["expiry_date"] < today
        ]
        
        expiring_soon = [
            t for t in self.training_records
            if t.get("expiry_date") and 0 <= (t["expiry_date"] - today).days <= 30
        ]
        
        if expired_training:
            return {
                "compliant": False,
                "status": "expired",
                "message": f"{len(expired_training)} training record(s) expired",
                "expired_training": expired_training
            }
        
        if expiring_soon:
            return {
                "compliant": True,
                "status": "expiring_soon",
                "message": f"{len(expiring_soon)} training record(s) expiring soon",
                "expiring_training": expiring_soon
            }
        
        return {
            "compliant": True,
            "status": "valid",
            "message": "All training is valid"
        }
    
    def _check_safety_status(self, today: date) -> Dict[str, Any]:
        """Check safety compliance status"""
        if not self.safety_records:
            return {
                "compliant": True,
                "status": "no_incidents",
                "message": "No safety incidents recorded"
            }
        
        # Check for incidents requiring WCB reporting
        wcb_overdue = [
            inc for inc in self.safety_records
            if inc.get("wcb_reporting_required") 
            and not inc["reported_to_wcb"]
            and inc.get("wcb_deadline")
            and inc["wcb_deadline"] < today
        ]
        
        # Check for open incidents
        open_incidents = [
            inc for inc in self.safety_records
            if inc["status"] == "open"
        ]
        
        if wcb_overdue:
            return {
                "compliant": False,
                "status": "wcb_overdue",
                "message": f"{len(wcb_overdue)} incident(s) require immediate WCB reporting",
                "overdue_incidents": wcb_overdue
            }
        
        if open_incidents:
            return {
                "compliant": True,
                "status": "open_incidents",
                "message": f"{len(open_incidents)} incident(s) require follow-up",
                "open_incidents": open_incidents
            }
        
        return {
            "compliant": True,
            "status": "resolved",
            "message": "All safety incidents resolved"
        }
    
    def _generate_action_items(
        self,
        wcb_status: Dict,
        permit_status: Dict,
        inspection_status: Dict,
        training_status: Dict,
        safety_status: Dict
    ) -> List[Dict[str, str]]:
        """Generate prioritized action items based on compliance status"""
        action_items = []
        
        # Critical priority items
        if not wcb_status["compliant"]:
            action_items.append({
                "priority": "critical",
                "category": "WCB",
                "action": wcb_status["message"],
                "deadline": "Immediate"
            })
        
        if not safety_status["compliant"]:
            action_items.append({
                "priority": "critical",
                "category": "Safety",
                "action": safety_status["message"],
                "deadline": "Immediate"
            })
        
        # High priority items
        if not permit_status["compliant"]:
            action_items.append({
                "priority": "high",
                "category": "Permits",
                "action": permit_status["message"],
                "deadline": "Within 7 days"
            })
        
        if not inspection_status["compliant"]:
            action_items.append({
                "priority": "high",
                "category": "Inspections",
                "action": inspection_status["message"],
                "deadline": "Within 14 days"
            })
        
        # Medium priority items
        if not training_status["compliant"]:
            action_items.append({
                "priority": "medium",
                "category": "Training",
                "action": training_status["message"],
                "deadline": "Within 30 days"
            })
        
        # Low priority items
        if permit_status["status"] == "expiring_soon":
            action_items.append({
                "priority": "low",
                "category": "Permits",
                "action": "Renew expiring permits",
                "deadline": "Before expiry"
            })
        
        if training_status["status"] == "expiring_soon":
            action_items.append({
                "priority": "low",
                "category": "Training",
                "action": "Schedule refresher training",
                "deadline": "Before expiry"
            })
        
        return action_items
    
    def generate_safety_checklist(self) -> Dict[str, List[str]]:
        """
        Generate weekly safety checklist based on Alberta OHS requirements
        
        Returns:
            Comprehensive safety checklist
        """
        return {
            "personal_protective_equipment": [
                "Hard hats available and worn",
                "Safety glasses/goggles available",
                "High-visibility vests worn",
                "Safety boots worn",
                "Gloves available for appropriate tasks",
                "Hearing protection available for noisy areas"
            ],
            "site_conditions": [
                "Walkways clear of debris",
                "Proper lighting in work areas",
                "Adequate ventilation",
                "Weather protection in place",
                "Signage posted (danger, caution, etc.)",
                "First aid kit accessible and stocked"
            ],
            "equipment_safety": [
                "Power tools in good condition",
                "Extension cords inspected",
                "Ladders secure and in good condition",
                "Scaffolding properly erected and tagged",
                "Heavy equipment inspected",
                "Guardrails in place where required"
            ],
            "fall_protection": [
                "Fall protection systems in place for heights > 3m",
                "Anchor points secure",
                "Harnesses inspected and properly worn",
                "Warning barriers around openings",
                "Floor openings covered or guarded"
            ],
            "electrical_safety": [
                "Lockout/tagout procedures followed",
                "Ground fault circuit interrupters (GFCI) used",
                "Electrical panels accessible",
                "Temporary wiring properly installed",
                "No exposed wiring"
            ],
            "fire_safety": [
                "Fire extinguishers accessible and inspected",
                "Flammable materials properly stored",
                "Hot work permits obtained when required",
                "Emergency exits clear",
                "Spill kits available"
            ],
            "documentation": [
                "Toolbox talk completed and documented",
                "Inspection reports up to date",
                "Incident reports filed if applicable",
                "Training records current",
                "Safety meeting minutes recorded"
            ]
        }


# Singleton instance
compliance_engine = ComplianceEngine()